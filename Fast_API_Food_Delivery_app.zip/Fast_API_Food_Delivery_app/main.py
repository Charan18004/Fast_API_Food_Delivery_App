from fastapi import FastAPI, Query, Response
from pydantic import BaseModel, Field
from typing import Optional
import math

app = FastAPI()

menu = [
    {"id": 1, "name": "Margherita Pizza", "price": 250, "category": "Pizza", "is_available": True},
    {"id": 2, "name": "Veg Burger", "price": 120, "category": "Burger", "is_available": True},
    {"id": 3, "name": "Coke", "price": 50, "category": "Drink", "is_available": True},
    {"id": 4, "name": "Chocolate Cake", "price": 140, "category": "Dessert", "is_available": False},
    {"id": 5, "name": "Paneer Pizza", "price": 300, "category": "Pizza", "is_available": True},
    {"id": 6, "name": "French Fries", "price": 90, "category": "Snack", "is_available": True}
]

orders = []
order_counter = 1
cart = []

class OrderRequest(BaseModel):
    customer_name: str = Field(..., min_length=2)
    item_id: int = Field(..., gt=0)
    quantity: int = Field(..., gt=0, le=20)
    delivery_address: str = Field(..., min_length=10)
    order_type: str = "delivery"


    
class CheckoutRequest(BaseModel):
    customer_name: str = Field(..., min_length=2)
    delivery_address: str = Field(..., min_length=10)
    
class NewMenuItem(BaseModel):
    name: str = Field(..., min_length=2)
    price: int = Field(..., gt=0)
    category: str = Field(..., min_length=2)
    is_available: bool = True        

def find_menu_item(item_id: int):
    for item in menu:
        if item["id"] == item_id:
            return item
    return None


def calculate_bill(price: int, quantity: int, order_type: str = "delivery"):
    total = price * quantity
    if order_type == "delivery":
        total += 30
    return total

def filter_menu_logic(category=None, max_price=None, is_available=None):
    filtered = menu

    if category is not None:
        filtered = [item for item in filtered if item["category"].lower() == category.lower()]

    if max_price is not None:
        filtered = [item for item in filtered if item["price"] <= max_price]

    if is_available is not None:
        filtered = [item for item in filtered if item["is_available"] == is_available]

    return filtered


@app.get("/")
def home():
    return {"message": "Welcome to QuickBite Food Delivery"}

@app.get("/menu")
def get_menu():
    return {"items": menu, "total": len(menu)}

@app.get("/menu/summary")
def menu_summary():
    available_count = sum(1 for item in menu if item["is_available"])
    unavailable_count = len(menu) - available_count
    categories = list(set(item["category"] for item in menu))

    return {
        "total_menu_items": len(menu),
        "available_items": available_count,
        "unavailable_items": unavailable_count,
        "categories": categories
    }

@app.get("/menu/filter")
def filter_menu(
    category: Optional[str] = None,
    max_price: Optional[int] = None,
    is_available: Optional[bool] = None
):
    filtered_items = filter_menu_logic(category, max_price, is_available)
    return {"items": filtered_items, "count": len(filtered_items)}

@app.get("/menu/search")
def search_menu(keyword: str):
    results = [
        item for item in menu
        if keyword.lower() in item["name"].lower()
        or keyword.lower() in item["category"].lower()
    ]

    if not results:
        return {"message": "No matching menu items found"}

    return {
        "items": results,
        "total_found": len(results)
    }

@app.get("/menu/sort")
def sort_menu(sort_by: str = "price", order: str = "asc"):
    allowed_fields = ["price", "name", "category"]

    if sort_by not in allowed_fields:
        return {"error": "Invalid sort_by field"}

    if order not in ["asc", "desc"]:
        return {"error": "Invalid order"}

    sorted_items = sorted(
        menu,
        key=lambda x: x[sort_by],
        reverse=(order == "desc")
    )

    return {
        "sort_by": sort_by,
        "order": order,
        "items": sorted_items
    }

@app.get("/menu/page")
def paginate_menu(
    page: int = Query(1, ge=1),
    limit: int = Query(3, ge=1, le=10)
):
    total = len(menu)
    total_pages = math.ceil(total / limit)

    start = (page - 1) * limit
    paginated_items = menu[start:start + limit]

    return {
        "page": page,
        "limit": limit,
        "total": total,
        "total_pages": total_pages,
        "items": paginated_items
    }

@app.get("/menu/browse")
def browse_menu(
    keyword: Optional[str] = None,
    sort_by: str = "price",
    order: str = "asc",
    page: int = Query(1, ge=1),
    limit: int = Query(4, ge=1, le=10)
):
    items = menu

    # Step 1: Filter
    if keyword is not None:
        items = [
            item for item in items
            if keyword.lower() in item["name"].lower()
            or keyword.lower() in item["category"].lower()
        ]

    # Step 2: Sort
    allowed_fields = ["price", "name", "category"]
    if sort_by not in allowed_fields:
        return {"error": "Invalid sort_by field"}

    if order not in ["asc", "desc"]:
        return {"error": "Invalid order"}

    items = sorted(
        items,
        key=lambda x: x[sort_by],
        reverse=(order == "desc")
    )

    # Step 3: Paginate
    total = len(items)
    total_pages = math.ceil(total / limit) if total > 0 else 1
    start = (page - 1) * limit
    paginated_items = items[start:start + limit]

    return {
        "keyword": keyword,
        "sort_by": sort_by,
        "order": order,
        "page": page,
        "limit": limit,
        "total": total,
        "total_pages": total_pages,
        "items": paginated_items
    }

@app.post("/menu")
def add_menu_item(item: NewMenuItem, response: Response):
    for existing_item in menu:
        if existing_item["name"].lower() == item.name.lower():
            return {"error": "Item already exists"}

    new_id = max(m["id"] for m in menu) + 1 if menu else 1

    new_item = {
        "id": new_id,
        "name": item.name,
        "price": item.price,
        "category": item.category,
        "is_available": item.is_available
    }

    menu.append(new_item)
    response.status_code = 201
    return new_item

@app.put("/menu/{item_id}")
def update_menu_item(
    item_id: int,
    price: Optional[int] = None,
    is_available: Optional[bool] = None
):
    item = find_menu_item(item_id)
    
    if item is None:
        return {"error": "Item not found"}

    if price is not None:
        item["price"] = price

    if is_available is not None:
        item["is_available"] = is_available

    return item

@app.delete("/menu/{item_id}")
def delete_menu_item(item_id: int):
    item = find_menu_item(item_id)

    if item is None:
        return {"error": "Item not found"}

    menu.remove(item)

    return {"message": f"{item['name']} deleted successfully"}

@app.get("/menu/{item_id}")
def get_menu_item(item_id: int):
    for item in menu:
        if item["id"] == item_id:
            return item
    return {"error": "Item not found"}

@app.post("/cart/add")
def add_to_cart(item_id: int, quantity: int = 1):
    item = find_menu_item(item_id)

    if item is None:
        return {"error": "Item not found"}

    if not item["is_available"]:
        return {"error": "Item is unavailable"}

    for cart_item in cart:
        if cart_item["item_id"] == item_id:
            cart_item["quantity"] += quantity
            return {"message": "Cart updated", "cart_item": cart_item}

    cart.append({
        "item_id": item_id,
        "item_name": item["name"],
        "price": item["price"],
        "quantity": quantity
    })

    return {"message": "Item added to cart", "cart": cart}

@app.get("/cart")
def get_cart():
    grand_total = sum(item["price"] * item["quantity"] for item in cart)

    return {
        "cart": cart,
        "grand_total": grand_total
    }

@app.post("/orders")
def place_order(order: OrderRequest):
    global order_counter

    item = None
    for i in menu:
        if i["id"] == order.item_id:
            item = i
            break

    if item is None:
        return {"error": "Item not found"}

    if not item["is_available"]:
        return {"error": "Item is currently unavailable"}

    total_price = calculate_bill(item["price"], order.quantity, order.order_type)

    new_order = {
        "order_id": order_counter,
        "order_type": order.order_type,
        "customer_name": order.customer_name,
        "item_id": order.item_id,
        "item_name": item["name"],
        "quantity": order.quantity,
        "delivery_address": order.delivery_address,
        "total_price": total_price
    }

    orders.append(new_order)
    order_counter += 1

    return new_order

@app.get("/orders")
def get_orders():
    return {
        "orders": orders,
        "total_orders": len(orders)
    }

@app.get("/orders/search")
def search_orders(customer_name: str):
    results = [
        order for order in orders
        if customer_name.lower() in order["customer_name"].lower()
    ]

    return {
        "orders": results,
        "total_found": len(results)
    }

@app.get("/orders/sort")
def sort_orders(order: str = "asc"):
    if order not in ["asc", "desc"]:
        return {"error": "Invalid order"}

    sorted_orders = sorted(
        orders,
        key=lambda x: x["total_price"],
        reverse=(order == "desc")
    )

    return {
        "order": order,
        "orders": sorted_orders
    }

@app.post("/cart/add")
def add_to_cart(item_id: int, quantity: int = 1):
    item = find_menu_item(item_id)
    if item is None:
        return {"error": "Item not found"}

    if not item["is_available"]:
        return {"error": "Item is unavailable"}

    for cart_item in cart:
        if cart_item["item_id"] == item_id:
            cart_item["quantity"] += quantity
            return {"message": "Cart updated", "cart_item": cart_item}

    cart.append({
        "item_id": item_id,
        "item_name": item["name"],
        "price": item["price"],
        "quantity": quantity
    })

    return {"message": "Item added to cart", "cart": cart}


@app.get("/cart")
def get_cart():
    grand_total = sum(item["price"] * item["quantity"] for item in cart)
    return {"cart": cart, "grand_total": grand_total}


@app.delete("/cart/{item_id}")
def remove_cart_item(item_id: int):
    for item in cart:
        if item["item_id"] == item_id:
            cart.remove(item)
            return {"message": "Item removed from cart"}

    return {"error": "Item not found in cart"}


@app.post("/cart/checkout")
def checkout(data: CheckoutRequest, response: Response):
    global order_counter

    if not cart:
        return {"error": "Cart is empty"}

    placed_orders = []
    grand_total = 0

    for cart_item in cart:
        total_price = cart_item["price"] * cart_item["quantity"] + 30

        new_order = {
            "order_id": order_counter,
            "customer_name": data.customer_name,
            "item_id": cart_item["item_id"],
            "item_name": cart_item["item_name"],
            "quantity": cart_item["quantity"],
            "delivery_address": data.delivery_address,
            "order_type": "delivery",
            "total_price": total_price
        }

        orders.append(new_order)
        placed_orders.append(new_order)
        grand_total += total_price
        order_counter += 1

    cart.clear()
    response.status_code = 201

    return {
        "placed_orders": placed_orders,
        "grand_total": grand_total
    }

